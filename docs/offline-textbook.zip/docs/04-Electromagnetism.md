# Electromagnetism

## Force on Current-carrying conductor in a Magnetic Field

Ah...

## Electromagnetic Induction

## Transformer
