# Electricity

## Current and Potential Difference


## Resistance

R = V/I

V = IR

## Electromotive Force (e.m.f) and Internal Resistance

## Electrical Energy and Power
